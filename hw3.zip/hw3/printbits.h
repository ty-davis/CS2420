#pragma once

void printlebits(void*, int);
void printbebits(void*, int);
