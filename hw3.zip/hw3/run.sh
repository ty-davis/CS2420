g++ testProgram.cpp printbits.cpp && ./a.out
